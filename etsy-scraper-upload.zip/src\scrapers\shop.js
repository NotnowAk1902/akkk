/**
 * Shop page scraper for Etsy
 */

import { SHOP_SELECTORS, LABELS } from '../utils/constants.js';
import { getPageNumber, randomDelay } from '../utils/helpers.js';

/**
 * Scrape shop page
 * @param {object} context - Playwright crawler context
 * @param {object} options - Scraping options
 */
export async function scrapeShop({ request, page, log, crawler }, options = {}) {
    const { endPage = 1, maxItems, state = {} } = options;

    const currentPage = getPageNumber(request.url);
    log.info(`Scraping shop page ${currentPage}: ${request.url}`);

    // Check if we've already reached the max items limit
    if (maxItems && (state.itemsScraped || 0) >= maxItems) {
        log.info('Max items limit already reached, skipping shop page');
        return;
    }

    // Wait for shop listings to load
    await page.waitForSelector(SHOP_SELECTORS.LISTING_ITEM, { timeout: 30000 }).catch(() => { });

    // Add random delay for anti-bot
    await randomDelay(500, 1500);

    // Extract shop info
    const shopName = await page.$eval(SHOP_SELECTORS.SHOP_NAME, el => el.textContent?.trim())
        .catch(() => null);

    log.info(`Shop name: ${shopName || 'Unknown'}`);

    // Extract product URLs from shop listings
    const productUrls = await page.$$eval(SHOP_SELECTORS.LISTING_LINK, links =>
        links.map(a => a.href)
            .filter(href => href && href.includes('/listing/'))
    );

    // Remove duplicates
    const uniqueUrls = [...new Set(productUrls)];

    log.info(`Found ${uniqueUrls.length} products on shop page ${currentPage}`);

    // Enqueue product pages for scraping
    let enqueuedCount = 0;
    for (const url of uniqueUrls) {
        // Check max items limit
        if (maxItems && (state.itemsScraped || 0) + enqueuedCount >= maxItems) {
            log.info('Max items limit reached, stopping enqueue');
            break;
        }

        await crawler.addRequests([{
            url,
            label: LABELS.PRODUCT,
            userData: { fromShop: true, shopName }
        }]);
        enqueuedCount++;
    }

    // Handle pagination - check if we should scrape next page
    if (currentPage < endPage) {
        // Check max items limit before adding next page
        if (!maxItems || (state.itemsScraped || 0) + enqueuedCount < maxItems) {
            const nextPageUrl = await page.$eval(SHOP_SELECTORS.NEXT_PAGE, a => a.href)
                .catch(() => null);

            if (nextPageUrl) {
                log.info(`Enqueueing next shop page: ${currentPage + 1}`);
                await crawler.addRequests([{
                    url: nextPageUrl,
                    label: LABELS.SHOP,
                    userData: { ...request.userData, shopName }
                }]);
            }
        }
    }

    log.info(`Enqueued ${enqueuedCount} products from shop page ${currentPage}`);
}
