# Etsy Scraper

An Apify Actor that scrapes Etsy product listings, search results, categories, and seller shops. Built with Crawlee and Playwright for reliable web scraping.

## Features

- 🔍 **Search scraping**: Scrape products by search keywords
- 📦 **Product details**: Extract comprehensive product information
- 🗂️ **Category scraping**: Scrape products from category pages
- 🏪 **Shop scraping**: Scrape all products from a seller's shop
- 📄 **Pagination support**: Automatically handles multi-page results
- 🛡️ **Anti-bot protection**: Uses Apify Proxy with random delays

## Input Parameters

| Parameter | Type | Description | Default |
|-----------|------|-------------|---------|
| `search` | String | Keywords to search on Etsy | - |
| `startUrls` | Array | Product, category, shop, or search URLs | - |
| `includeDescription` | Boolean | Fetch full product description | `false` |
| `endPage` | Number | Maximum pages to scrape | `10` |
| `maxItems` | Number | Maximum items to scrape | unlimited |
| `proxy` | Object | Apify Proxy configuration | Residential |

## Example Input

### Search by keyword
```json
{
    "search": "leather wallet",
    "maxItems": 10
}
```

### Scrape specific product
```json
{
    "startUrls": [
        { "url": "https://www.etsy.com/listing/123456789/product-name" }
    ],
    "includeDescription": true
}
```

### Scrape a shop
```json
{
    "startUrls": [
        { "url": "https://www.etsy.com/shop/ShopName" }
    ],
    "endPage": 5,
    "maxItems": 50
}
```

## Output

Each product is saved with the following fields:

```json
{
    "url": "https://www.etsy.com/listing/...",
    "name": "Product Name",
    "price": 29.99,
    "originalPrice": 39.99,
    "currency": "USD",
    "images": ["https://..."],
    "seller": {
        "name": "ShopName",
        "url": "https://www.etsy.com/shop/ShopName",
        "rating": 4.9,
        "numberOfReviews": 1234
    },
    "variations": [
        { "label": "Color", "options": ["Red", "Blue"] }
    ],
    "highlights": ["Handmade", "Free shipping"],
    "favorites": 500,
    "description": "Product description...",
    "scrapedAt": "2024-01-01T00:00:00.000Z"
}
```

## Running Locally

```bash
# Install dependencies
npm install

# Run with Apify CLI
npx apify-cli run -p '{"search": "leather wallet", "maxItems": 5}'
```

## Deploy to Apify

```bash
# Login to Apify
npx apify-cli login

# Push to Apify platform
npx apify-cli push
```

## Notes

- **Proxy Required**: Etsy has anti-bot protection. Residential proxies are recommended.
- **Rate Limiting**: The actor includes random delays between requests.
- **Selector Updates**: Etsy's HTML may change. Selectors may need updates over time.

## License

ISC
