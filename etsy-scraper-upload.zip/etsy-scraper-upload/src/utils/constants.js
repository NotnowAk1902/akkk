/**
 * URL patterns and CSS selectors for Etsy scraping
 */

export const BASE_URL = 'https://www.etsy.com';

// URL patterns for page type detection
export const URL_PATTERNS = {
    PRODUCT: /\/listing\/(\d+)/,
    SEARCH: /\/search\?|search_query=/,
    CATEGORY: /\/c\/([^/?]+)/,
    SHOP: /\/shop\/([^/?]+)/,
};

// Labels for request routing
export const LABELS = {
    PRODUCT: 'PRODUCT',
    SEARCH: 'SEARCH',
    CATEGORY: 'CATEGORY',
    SHOP: 'SHOP',
};

// CSS selectors for product page
export const PRODUCT_SELECTORS = {
    NAME: 'h1[data-buy-box-listing-title]',
    PRICE: '[data-buy-box-region="price"] .wt-text-title-largest',
    ORIGINAL_PRICE: '[data-buy-box-region="price"] .wt-text-strikethrough',
    CURRENCY: '[data-buy-box-region="price"] .currency-symbol',
    IMAGES: '[data-carousel-paging-container] img, [data-component="listing-page-image-carousel"] img',
    SELLER_NAME: '[data-shop-name] a, a[href*="/shop/"]',
    SELLER_RATING: '[data-rating] span, .wt-text-title-small[aria-hidden="true"]',
    SELLER_REVIEWS: 'a[href*="reviews"]',
    DESCRIPTION: '[data-product-details-description-text-content]',
    VARIATIONS: '[data-selector="listing-page-variation"]',
    VARIATION_OPTION: 'select option, [data-variation-option]',
    FAVORITES: '.wt-text-caption[class*="favorite"]',
    HIGHLIGHTS: '[data-component="ListingAttributeList"] li',
    LISTED_ON: 'span:has-text("Listed on")',
    BREADCRUMBS: 'nav[aria-label="Breadcrumbs"] a',
};

// CSS selectors for search/category results
export const SEARCH_SELECTORS = {
    LISTING_ITEM: '[data-search-results] [data-listing-id], .wt-grid [data-listing-id]',
    LISTING_LINK: 'a[href*="/listing/"]',
    NEXT_PAGE: 'a[data-page][rel="next"], nav a[href*="page="]',
    TOTAL_RESULTS: '[data-results-count], .wt-text-caption'
};

// CSS selectors for shop page
export const SHOP_SELECTORS = {
    LISTING_ITEM: '[data-listing-id]',
    LISTING_LINK: 'a[href*="/listing/"]',
    SHOP_NAME: 'h1[class*="shop-name"], .wt-text-heading',
    SHOP_RATING: '[data-rating-value]',
    TOTAL_SALES: 'span:has-text("sales")',
    NEXT_PAGE: 'a[data-page][rel="next"]',
};
