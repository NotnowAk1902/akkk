/**
 * Utility functions for Etsy scraping
 */

/**
 * Parse price from text, handling various formats
 * @param {string} text - Price text like "$29.99" or "USD 29.99"
 * @returns {object} - { price: number, currency: string }
 */
export function parsePrice(text) {
    if (!text) return { price: null, currency: null };

    const cleaned = text.trim().replace(/\s+/g, ' ');

    // Extract currency symbol or code
    const currencyMatch = cleaned.match(/([A-Z]{3}|[$€£¥₹])/);
    const currency = currencyMatch ? currencyMatch[1] : 'USD';

    // Extract numeric value
    const priceMatch = cleaned.match(/[\d,]+\.?\d*/);
    const price = priceMatch ? parseFloat(priceMatch[0].replace(/,/g, '')) : null;

    return { price, currency };
}

/**
 * Clean text by normalizing whitespace
 * @param {string} text - Input text
 * @returns {string} - Cleaned text
 */
export function cleanText(text) {
    if (!text) return '';
    return text.trim().replace(/\s+/g, ' ');
}

/**
 * Extract page number from URL
 * @param {string} url - URL string
 * @returns {number} - Page number (1 if not found)
 */
export function getPageNumber(url) {
    const match = url.match(/[?&]page=(\d+)/);
    return match ? parseInt(match[1], 10) : 1;
}

/**
 * Random delay for anti-bot measures
 * @param {number} minMs - Minimum delay in milliseconds
 * @param {number} maxMs - Maximum delay in milliseconds
 * @returns {Promise} - Resolves after random delay
 */
export function randomDelay(minMs = 1000, maxMs = 3000) {
    const delay = Math.floor(Math.random() * (maxMs - minMs + 1)) + minMs;
    return new Promise(resolve => setTimeout(resolve, delay));
}

/**
 * Extract listing ID from URL
 * @param {string} url - Etsy listing URL
 * @returns {string|null} - Listing ID or null
 */
export function extractListingId(url) {
    const match = url.match(/\/listing\/(\d+)/);
    return match ? match[1] : null;
}

/**
 * Build search URL from keywords
 * @param {string} keywords - Search keywords
 * @param {number} page - Page number
 * @returns {string} - Search URL
 */
export function buildSearchUrl(keywords, page = 1) {
    const encoded = encodeURIComponent(keywords);
    return `https://www.etsy.com/search?q=${encoded}&page=${page}`;
}

/**
 * Check if we've reached the max items limit
 * @param {object} state - Crawler state
 * @param {number} maxItems - Maximum items limit
 * @returns {boolean} - True if limit reached
 */
export function isMaxItemsReached(state, maxItems) {
    if (!maxItems) return false;
    return (state.itemsScraped || 0) >= maxItems;
}

/**
 * Parse number from text (e.g., "1,234 sales" -> 1234)
 * @param {string} text - Text containing number
 * @returns {number|null} - Parsed number or null
 */
export function parseNumber(text) {
    if (!text) return null;
    const match = text.match(/[\d,]+/);
    return match ? parseInt(match[0].replace(/,/g, ''), 10) : null;
}

/**
 * Extract all images from various img elements
 * @param {object} page - Playwright page object
 * @param {string} selector - CSS selector for images
 * @returns {Promise<string[]>} - Array of image URLs
 */
export async function extractImages(page, selector) {
    const images = await page.$$eval(selector, imgs =>
        imgs.map(img => img.src || img.getAttribute('data-src'))
            .filter(src => src && !src.includes('placeholder'))
            .map(src => {
                // Get highest quality version
                if (src.includes('il_')) {
                    return src.replace(/il_\d+x\d+/, 'il_fullxfull');
                }
                return src;
            })
    );
    // Remove duplicates
    return [...new Set(images)];
}
