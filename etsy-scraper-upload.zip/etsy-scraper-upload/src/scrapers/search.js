/**
 * Search results page scraper for Etsy
 */

import { SEARCH_SELECTORS, LABELS, BASE_URL } from '../utils/constants.js';
import { getPageNumber, randomDelay } from '../utils/helpers.js';

/**
 * Scrape search results page
 * @param {object} context - Playwright crawler context
 * @param {object} options - Scraping options
 */
export async function scrapeSearch({ request, page, log, crawler }, options = {}) {
    const { endPage = 10, maxItems, state } = options;

    const currentPage = getPageNumber(request.url);
    log.info(`Scraping search page ${currentPage}: ${request.url}`);

    // Wait for search results to load
    await page.waitForSelector(SEARCH_SELECTORS.LISTING_ITEM, { timeout: 30000 }).catch(() => { });

    // Add random delay for anti-bot
    await randomDelay(500, 1500);

    // Extract product URLs from search results
    const productUrls = await page.$$eval(SEARCH_SELECTORS.LISTING_LINK, links =>
        links.map(a => a.href)
            .filter(href => href && href.includes('/listing/'))
    );

    // Remove duplicates
    const uniqueUrls = [...new Set(productUrls)];

    log.info(`Found ${uniqueUrls.length} products on search page ${currentPage}`);

    // Enqueue product pages for scraping
    let enqueuedCount = 0;
    for (const url of uniqueUrls) {
        // Check max items limit
        if (maxItems && (state.itemsScraped || 0) + enqueuedCount >= maxItems) {
            log.info('Max items limit reached, stopping enqueue');
            break;
        }

        await crawler.addRequests([{
            url,
            label: LABELS.PRODUCT,
            userData: { fromSearch: true }
        }]);
        enqueuedCount++;
    }

    // Handle pagination - check if we should scrape next page
    if (currentPage < endPage) {
        // Check max items limit before adding next page
        if (!maxItems || (state.itemsScraped || 0) + enqueuedCount < maxItems) {
            const nextPageUrl = await page.$eval(SEARCH_SELECTORS.NEXT_PAGE, a => a.href)
                .catch(() => null);

            if (nextPageUrl) {
                log.info(`Enqueueing next page: ${currentPage + 1}`);
                await crawler.addRequests([{
                    url: nextPageUrl,
                    label: LABELS.SEARCH,
                    userData: { ...request.userData }
                }]);
            }
        }
    }

    log.info(`Enqueued ${enqueuedCount} products from search page ${currentPage}`);
}
