/**
 * Category page scraper for Etsy
 */

import { SEARCH_SELECTORS, LABELS } from '../utils/constants.js';
import { getPageNumber, randomDelay } from '../utils/helpers.js';

/**
 * Scrape category listing page
 * @param {object} context - Playwright crawler context
 * @param {object} options - Scraping options
 */
export async function scrapeCategory({ request, page, log, crawler }, options = {}) {
    const { endPage = 10, maxItems, state } = options;

    const currentPage = getPageNumber(request.url);
    log.info(`Scraping category page ${currentPage}: ${request.url}`);

    // Wait for category listings to load
    await page.waitForSelector(SEARCH_SELECTORS.LISTING_ITEM, { timeout: 30000 }).catch(() => { });

    // Add random delay for anti-bot
    await randomDelay(500, 1500);

    // Extract product URLs from category
    const productUrls = await page.$$eval(SEARCH_SELECTORS.LISTING_LINK, links =>
        links.map(a => a.href)
            .filter(href => href && href.includes('/listing/'))
    );

    // Remove duplicates
    const uniqueUrls = [...new Set(productUrls)];

    log.info(`Found ${uniqueUrls.length} products in category page ${currentPage}`);

    // Enqueue product pages for scraping
    let enqueuedCount = 0;
    for (const url of uniqueUrls) {
        // Check max items limit
        if (maxItems && (state.itemsScraped || 0) + enqueuedCount >= maxItems) {
            log.info('Max items limit reached, stopping enqueue');
            break;
        }

        await crawler.addRequests([{
            url,
            label: LABELS.PRODUCT,
            userData: { fromCategory: true }
        }]);
        enqueuedCount++;
    }

    // Handle pagination
    if (currentPage < endPage) {
        if (!maxItems || (state.itemsScraped || 0) + enqueuedCount < maxItems) {
            const nextPageUrl = await page.$eval(SEARCH_SELECTORS.NEXT_PAGE, a => a.href)
                .catch(() => null);

            if (nextPageUrl) {
                log.info(`Enqueueing next category page: ${currentPage + 1}`);
                await crawler.addRequests([{
                    url: nextPageUrl,
                    label: LABELS.CATEGORY,
                    userData: { ...request.userData }
                }]);
            }
        }
    }

    log.info(`Enqueued ${enqueuedCount} products from category page ${currentPage}`);
}
