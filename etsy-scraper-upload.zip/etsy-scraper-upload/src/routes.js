/**
 * URL Router for Etsy Scraper
 * Routes requests to appropriate scrapers based on URL patterns
 */

import { createPlaywrightRouter } from '@crawlee/playwright';
import { URL_PATTERNS, LABELS } from './utils/constants.js';
import { scrapeProduct } from './scrapers/product.js';
import { scrapeSearch } from './scrapers/search.js';
import { scrapeCategory } from './scrapers/category.js';
import { scrapeShop } from './scrapers/shop.js';

export const router = createPlaywrightRouter();

// Store for scraping options (set by main.js)
export let scrapingOptions = {};

export function setScrapingOptions(options) {
    scrapingOptions = options;
}

/**
 * Determine page type from URL
 */
export function getPageLabel(url) {
    if (URL_PATTERNS.PRODUCT.test(url)) return LABELS.PRODUCT;
    if (URL_PATTERNS.SEARCH.test(url)) return LABELS.SEARCH;
    if (URL_PATTERNS.CATEGORY.test(url)) return LABELS.CATEGORY;
    if (URL_PATTERNS.SHOP.test(url)) return LABELS.SHOP;
    return LABELS.SEARCH; // Default to search for unknown URLs
}

// Default handler - determine page type and route accordingly
router.addDefaultHandler(async (context) => {
    const { request, log } = context;
    const label = getPageLabel(request.url);

    log.info(`Routing URL to ${label}: ${request.url}`);

    switch (label) {
        case LABELS.PRODUCT:
            await scrapeProduct(context, scrapingOptions);
            break;
        case LABELS.SEARCH:
            await scrapeSearch(context, scrapingOptions);
            break;
        case LABELS.CATEGORY:
            await scrapeCategory(context, scrapingOptions);
            break;
        case LABELS.SHOP:
            await scrapeShop(context, scrapingOptions);
            break;
        default:
            log.warning(`Unknown page type for URL: ${request.url}`);
    }
});

// Product page handler
router.addHandler(LABELS.PRODUCT, async (context) => {
    await scrapeProduct(context, scrapingOptions);
});

// Search results handler
router.addHandler(LABELS.SEARCH, async (context) => {
    await scrapeSearch(context, scrapingOptions);
});

// Category page handler
router.addHandler(LABELS.CATEGORY, async (context) => {
    await scrapeCategory(context, scrapingOptions);
});

// Shop page handler
router.addHandler(LABELS.SHOP, async (context) => {
    await scrapeShop(context, scrapingOptions);
});
