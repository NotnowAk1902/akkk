/**
 * Product detail page scraper for Etsy
 */

import { Dataset } from '@crawlee/playwright';
import { PRODUCT_SELECTORS } from '../utils/constants.js';
import {
    parsePrice,
    cleanText,
    parseNumber,
    extractImages,
    applyExtendOutputFunction,
    applyCustomMapFunction,
    extractVariationPrices
} from '../utils/helpers.js';

/**
 * Scrape product detail page
 * @param {object} context - Playwright crawler context
 * @param {object} options - Scraping options
 */
export async function scrapeProduct({ request, page, log }, options = {}) {
    const {
        includeDescription = false,
        includeVariationPrices = false,
        extendOutputFn = null,
        customMapFn = null,
        state = {},
        maxItems
    } = options;

    // Check if we've reached max items
    if (maxItems && (state.itemsScraped || 0) >= maxItems) {
        log.info('Max items limit reached, skipping product');
        return null;
    }

    log.info(`Scraping product: ${request.url}`);

    // Wait for main content to load
    await page.waitForSelector(PRODUCT_SELECTORS.NAME, { timeout: 30000 }).catch(() => { });

    // Extract product name
    const name = await page.$eval(PRODUCT_SELECTORS.NAME, el => el.textContent?.trim())
        .catch(() => null);

    // Extract price info
    const priceText = await page.$eval(PRODUCT_SELECTORS.PRICE, el => el.textContent?.trim())
        .catch(() => null);
    const { price, currency } = parsePrice(priceText);

    // Extract original price if on sale
    const originalPriceText = await page.$eval(PRODUCT_SELECTORS.ORIGINAL_PRICE, el => el.textContent?.trim())
        .catch(() => null);
    const originalPrice = originalPriceText ? parsePrice(originalPriceText).price : null;

    // Extract images
    const images = await extractImages(page, PRODUCT_SELECTORS.IMAGES);

    // Extract seller info
    const sellerName = await page.$eval(PRODUCT_SELECTORS.SELLER_NAME, el => el.textContent?.trim())
        .catch(() => null);
    const sellerUrl = await page.$eval(PRODUCT_SELECTORS.SELLER_NAME, el => el.href)
        .catch(() => null);
    const sellerRatingText = await page.$eval(PRODUCT_SELECTORS.SELLER_RATING, el => el.textContent?.trim())
        .catch(() => null);
    const sellerReviewsText = await page.$eval(PRODUCT_SELECTORS.SELLER_REVIEWS, el => el.textContent?.trim())
        .catch(() => null);

    // Extract variations (size, color, etc.)
    const variations = await page.$$eval(PRODUCT_SELECTORS.VARIATIONS, els =>
        els.map(el => {
            const label = el.querySelector('label')?.textContent?.trim() || '';
            const options = Array.from(el.querySelectorAll('option, [data-variation-option]'))
                .map(opt => opt.textContent?.trim())
                .filter(Boolean);
            return { label, options };
        })
    ).catch(() => []);

    // Extract variation prices if requested
    let variationPrices = [];
    if (includeVariationPrices) {
        log.info('Extracting variation prices...');
        variationPrices = await extractVariationPrices(page);
        log.info(`Found ${variationPrices.length} variation price entries`);
    }

    // Extract highlights
    const highlights = await page.$$eval(PRODUCT_SELECTORS.HIGHLIGHTS, els =>
        els.map(el => el.textContent?.trim()).filter(Boolean)
    ).catch(() => []);

    // Extract favorites count
    const favoritesText = await page.$eval(PRODUCT_SELECTORS.FAVORITES, el => el.textContent?.trim())
        .catch(() => null);
    const favorites = parseNumber(favoritesText);

    // Extract description if requested
    let description = null;
    let descriptionHTML = null;
    if (includeDescription) {
        descriptionHTML = await page.$eval(PRODUCT_SELECTORS.DESCRIPTION, el => el.innerHTML)
            .catch(() => null);
        description = await page.$eval(PRODUCT_SELECTORS.DESCRIPTION, el => el.textContent?.trim())
            .catch(() => null);
    }

    // Build product data object
    let productData = {
        url: request.url,
        name,
        price,
        originalPrice,
        currency,
        images,
        seller: {
            name: sellerName,
            url: sellerUrl,
            rating: sellerRatingText ? parseFloat(sellerRatingText) : null,
            numberOfReviews: parseNumber(sellerReviewsText),
        },
        variations,
        variationPrices: includeVariationPrices ? variationPrices : undefined,
        highlights,
        favorites,
        description,
        descriptionHTML,
        scrapedAt: new Date().toISOString(),
    };

    // Apply extend output function if provided
    if (extendOutputFn) {
        try {
            const html = await page.content();
            const extendedFields = await applyExtendOutputFunction(html, extendOutputFn);
            productData = { ...productData, ...extendedFields };
        } catch (error) {
            log.warning(`Error applying extendOutputFunction: ${error.message}`);
        }
    }

    // Apply custom map function if provided
    if (customMapFn) {
        try {
            productData = await applyCustomMapFunction(productData, customMapFn);
        } catch (error) {
            log.warning(`Error applying customMapFunction: ${error.message}`);
        }
    }

    // Push to dataset
    await Dataset.pushData(productData);

    // Update state
    state.itemsScraped = (state.itemsScraped || 0) + 1;

    log.info(`Scraped product: ${name || 'Unknown'} - ${currency}${price} (${state.itemsScraped} total)`);

    return productData;
}
