/**
 * Utility functions for Etsy scraping
 */

import * as cheerio from 'cheerio';

/**
 * Parse price from text, handling various formats
 * @param {string} text - Price text like "$29.99" or "USD 29.99"
 * @returns {object} - { price: number, currency: string }
 */
export function parsePrice(text) {
    if (!text) return { price: null, currency: null };

    const cleaned = text.trim().replace(/\s+/g, ' ');

    // Extract currency symbol or code
    const currencyMatch = cleaned.match(/([A-Z]{3}|[$€£¥₹])/);
    const currency = currencyMatch ? currencyMatch[1] : 'USD';

    // Extract numeric value
    const priceMatch = cleaned.match(/[\d,]+\.?\d*/);
    const price = priceMatch ? parseFloat(priceMatch[0].replace(/,/g, '')) : null;

    return { price, currency };
}

/**
 * Clean text by normalizing whitespace
 * @param {string} text - Input text
 * @returns {string} - Cleaned text
 */
export function cleanText(text) {
    if (!text) return '';
    return text.trim().replace(/\s+/g, ' ');
}

/**
 * Extract page number from URL
 * @param {string} url - URL string
 * @returns {number} - Page number (1 if not found)
 */
export function getPageNumber(url) {
    const match = url.match(/[?&]page=(\d+)/);
    return match ? parseInt(match[1], 10) : 1;
}

/**
 * Random delay for anti-bot measures
 * @param {number} minMs - Minimum delay in milliseconds
 * @param {number} maxMs - Maximum delay in milliseconds
 * @returns {Promise} - Resolves after random delay
 */
export function randomDelay(minMs = 1000, maxMs = 3000) {
    const delay = Math.floor(Math.random() * (maxMs - minMs + 1)) + minMs;
    return new Promise(resolve => setTimeout(resolve, delay));
}

/**
 * Extract listing ID from URL
 * @param {string} url - Etsy listing URL
 * @returns {string|null} - Listing ID or null
 */
export function extractListingId(url) {
    const match = url.match(/\/listing\/(\d+)/);
    return match ? match[1] : null;
}

/**
 * Build search URL from keywords
 * @param {string} keywords - Search keywords
 * @param {number} page - Page number
 * @returns {string} - Search URL
 */
export function buildSearchUrl(keywords, page = 1) {
    const encoded = encodeURIComponent(keywords);
    return `https://www.etsy.com/search?q=${encoded}&page=${page}`;
}

/**
 * Check if we've reached the max items limit
 * @param {object} state - Crawler state
 * @param {number} maxItems - Maximum items limit
 * @returns {boolean} - True if limit reached
 */
export function isMaxItemsReached(state, maxItems) {
    if (!maxItems) return false;
    return (state.itemsScraped || 0) >= maxItems;
}

/**
 * Parse number from text (e.g., "1,234 sales" -> 1234)
 * @param {string} text - Text containing number
 * @returns {number|null} - Parsed number or null
 */
export function parseNumber(text) {
    if (!text) return null;
    const match = text.match(/[\d,]+/);
    return match ? parseInt(match[0].replace(/,/g, ''), 10) : null;
}

/**
 * Extract all images from various img elements
 * @param {object} page - Playwright page object
 * @param {string} selector - CSS selector for images
 * @returns {Promise<string[]>} - Array of image URLs
 */
export async function extractImages(page, selector) {
    const images = await page.$$eval(selector, imgs =>
        imgs.map(img => img.src || img.getAttribute('data-src'))
            .filter(src => src && !src.includes('placeholder'))
            .map(src => {
                // Get highest quality version
                if (src.includes('il_')) {
                    return src.replace(/il_\d+x\d+/, 'il_fullxfull');
                }
                return src;
            })
    );
    // Remove duplicates
    return [...new Set(images)];
}

/**
 * Evaluate and validate the extend output function
 * @param {string} funcString - The function string from input
 * @returns {Function} - Compiled function
 */
export function evalExtendOutputFunction(funcString) {
    if (!funcString || typeof funcString !== 'string') {
        return null;
    }

    try {
        // Wrap the function string and evaluate
        const fn = eval(funcString);
        if (typeof fn !== 'function') {
            throw new Error('extendOutputFunction must be a function');
        }
        return fn;
    } catch (error) {
        throw new Error(`Failed to evaluate extendOutputFunction: ${error.message}`);
    }
}

/**
 * Evaluate and validate the custom map function
 * @param {string} funcString - The function string from input
 * @returns {Function} - Compiled function
 */
export function evalCustomMapFunction(funcString) {
    if (!funcString || typeof funcString !== 'string') {
        return null;
    }

    try {
        // Wrap the function string and evaluate
        const fn = eval(funcString);
        if (typeof fn !== 'function') {
            throw new Error('customMapFunction must be a function');
        }
        return fn;
    } catch (error) {
        throw new Error(`Failed to evaluate customMapFunction: ${error.message}`);
    }
}

/**
 * Apply extend output function to get additional fields
 * @param {string} html - Page HTML content
 * @param {Function} extendOutputFn - The extend output function
 * @returns {object} - Additional fields from extend function
 */
export async function applyExtendOutputFunction(html, extendOutputFn) {
    if (!extendOutputFn || !html) {
        return {};
    }

    try {
        const $ = cheerio.load(html);
        const result = await extendOutputFn($);
        return result || {};
    } catch (error) {
        console.error('Error in extendOutputFunction:', error.message);
        return {};
    }
}

/**
 * Apply custom map function to transform result
 * @param {object} data - Original data object
 * @param {Function} customMapFn - The custom map function
 * @returns {object} - Transformed data object
 */
export async function applyCustomMapFunction(data, customMapFn) {
    if (!customMapFn || !data) {
        return data;
    }

    try {
        const result = await customMapFn(data);
        return result || data;
    } catch (error) {
        console.error('Error in customMapFunction:', error.message);
        return data;
    }
}

/**
 * Extract variation prices from product page
 * @param {object} page - Playwright page object
 * @returns {Promise<Array>} - Array of variation price objects
 */
export async function extractVariationPrices(page) {
    try {
        // Try to extract variation data from the page
        const variations = await page.evaluate(() => {
            const variationData = [];

            // Find all variation selectors
            const variationContainers = document.querySelectorAll('[data-selector="listing-page-variation"], [data-variation-select-id]');

            variationContainers.forEach(container => {
                const label = container.querySelector('label')?.textContent?.trim() ||
                    container.getAttribute('data-variation-name') || 'Variation';

                // Get options from select elements
                const selectEl = container.querySelector('select');
                if (selectEl) {
                    Array.from(selectEl.options).forEach(option => {
                        if (option.value && option.textContent) {
                            const text = option.textContent.trim();
                            // Try to extract price from option text (e.g., "Red (+$5.00)")
                            const priceMatch = text.match(/\(\+?\$?([\d,.]+)\)/);
                            variationData.push({
                                variationType: label,
                                variationValue: text.replace(/\(\+?\$?[\d,.]+\)/, '').trim(),
                                priceModifier: priceMatch ? parseFloat(priceMatch[1].replace(',', '')) : 0,
                                fullText: text
                            });
                        }
                    });
                }

                // Get options from button/swatch elements
                const swatches = container.querySelectorAll('[data-variation-option], button[aria-label]');
                swatches.forEach(swatch => {
                    const value = swatch.getAttribute('data-variation-option') ||
                        swatch.getAttribute('aria-label') ||
                        swatch.textContent?.trim();
                    if (value) {
                        variationData.push({
                            variationType: label,
                            variationValue: value,
                            priceModifier: 0,
                            fullText: value
                        });
                    }
                });
            });

            return variationData;
        });

        return variations;
    } catch (error) {
        console.error('Error extracting variation prices:', error.message);
        return [];
    }
}
