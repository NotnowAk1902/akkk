/**
 * Etsy Scraper - Main Entry Point
 * Scrapes Etsy product listings, search results, categories, and seller shops.
 * Template: Crawlee + Playwright + Chrome (JavaScript)
 */

import { PlaywrightCrawler, Dataset } from '@crawlee/playwright';
import { Actor } from 'apify';
import { router, setScrapingOptions, getPageLabel } from './routes.js';
import { buildSearchUrl, randomDelay, evalExtendOutputFunction, evalCustomMapFunction } from './utils/helpers.js';
import { LABELS } from './utils/constants.js';

// Initialize the Apify SDK
await Actor.init();

// Get input configuration
const input = await Actor.getInput() ?? {};

const {
    startUrls = [],
    includeDescription = false,
    includeVariationPrices = false,
    maximumNumberOfItems = 10,
    categoryEndPage = 1,
    search = '',
    extendOutputFunction,
    customMapFunction,
    proxy = { useApifyProxy: true, apifyProxyGroups: ['RESIDENTIAL'] }
} = input;

// Validate input - need either search or startUrls
if (!search && (!startUrls || startUrls.length === 0)) {
    throw new Error('Either "search" keyword or "startUrls" must be provided!');
}

console.log('Etsy Scraper started with config:', {
    startUrls: startUrls.length,
    includeDescription,
    includeVariationPrices,
    maximumNumberOfItems,
    categoryEndPage,
    search: search || '(none)',
    hasExtendOutputFunction: !!extendOutputFunction,
    hasCustomMapFunction: !!customMapFunction
});

// Validate custom functions if provided
let extendOutputFn = null;
let customMapFn = null;

if (extendOutputFunction) {
    try {
        extendOutputFn = evalExtendOutputFunction(extendOutputFunction);
        console.log('Extend output function validated successfully');
    } catch (error) {
        throw new Error(`Invalid extendOutputFunction: ${error.message}`);
    }
}

if (customMapFunction) {
    try {
        customMapFn = evalCustomMapFunction(customMapFunction);
        console.log('Custom map function validated successfully');
    } catch (error) {
        throw new Error(`Invalid customMapFunction: ${error.message}`);
    }
}

// Create state for tracking progress
const state = {
    itemsScraped: 0
};

// Set scraping options for routes
setScrapingOptions({
    includeDescription,
    includeVariationPrices,
    endPage: categoryEndPage,
    maxItems: maximumNumberOfItems,
    extendOutputFn,
    customMapFn,
    state
});

// Configure proxy
const proxyConfiguration = await Actor.createProxyConfiguration(proxy);

// Create the crawler
const crawler = new PlaywrightCrawler({
    proxyConfiguration,
    requestHandler: router,

    // Browser launch options
    launchContext: {
        launchOptions: {
            args: [
                '--disable-gpu',
                '--disable-dev-shm-usage',
                '--no-sandbox',
            ],
        },
    },

    // Playwright navigation options
    navigationTimeoutSecs: 60,
    requestHandlerTimeoutSecs: 120,

    // Anti-bot measures
    maxConcurrency: 3,

    // Pre-navigation hook for stealth
    preNavigationHooks: [
        async ({ page }) => {
            // Set realistic viewport
            await page.setViewportSize({ width: 1366, height: 768 });

            // Add random delay before navigation
            await randomDelay(500, 1500);
        }
    ],

    // Error handling
    maxRequestRetries: 3,

    // Session rotation
    sessionPoolOptions: {
        maxPoolSize: 10,
        sessionOptions: {
            maxUsageCount: 5,
        }
    },

    // Failed request handler
    failedRequestHandler: async ({ request, error }, error2) => {
        console.error(`Request failed: ${request.url}`, error || error2);
    },
});

// Build initial requests
const initialRequests = [];

// Add search URL if search keyword provided
if (search) {
    const searchUrl = buildSearchUrl(search);
    initialRequests.push({
        url: searchUrl,
        label: LABELS.SEARCH,
        userData: { searchKeyword: search }
    });
    console.log(`Added search URL: ${searchUrl}`);
}

// Add start URLs with appropriate labels
for (const urlConfig of startUrls) {
    const url = typeof urlConfig === 'string' ? urlConfig : urlConfig.url;
    if (url) {
        const label = getPageLabel(url);
        initialRequests.push({
            url,
            label,
            userData: urlConfig.userData || {}
        });
        console.log(`Added start URL (${label}): ${url}`);
    }
}

// Run the crawler
console.log(`Starting crawler with ${initialRequests.length} initial request(s)...`);
await crawler.run(initialRequests);

// Get stats
const datasetInfo = await Dataset.getData();
console.log(`Scraping complete! Total items scraped: ${datasetInfo.count || 0}`);

// Exit successfully
await Actor.exit();
