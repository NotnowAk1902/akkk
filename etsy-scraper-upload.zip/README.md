# Etsy Scraper

Scrape valuable data from over 4 million Etsy sellers. Extract product details, descriptions, listed date, images, seller info, and more. Customize your searches and filters to gather the desired information effortlessly.

## Features

- **Product Scraping**: Extract detailed product information including name, price, images, variations, and seller details
- **Search Results**: Scrape products from Etsy search results by keyword
- **Category Pages**: Scrape all products from Etsy category pages
- **Shop Scraping**: Extract all products from a specific Etsy seller's shop
- **Variation Prices**: Optionally extract all variation prices for products
- **Custom Output**: Extend output with custom fields using JavaScript functions
- **Anti-Bot Measures**: Built-in delays, session rotation, and residential proxy support

## Input Configuration

### Start URLs
Add one or more Etsy URLs to scrape. Supported URL types:
- **Product URLs**: `https://www.etsy.com/listing/743657804/...`
- **Search URLs**: `https://www.etsy.com/search?q=apple%20watch`
- **Category URLs**: `https://www.etsy.com/c/clothing-and-shoes`
- **Shop URLs**: `https://www.etsy.com/shop/ShopName`

### Include Description
Enable to fetch the full product description for each listing. This option can increase the scrape time.

### Include Variation Prices
Enable to include all variation prices for products. This includes all the prices for all the variations of a product. **Please be aware that this option increases the runtime dramatically.**

### Maximum number of items
Set the maximum number of products to scrape. Default is 10.

### Category end page
Set the maximum page number to scrape for category/search/shop results. Default is 1.

### Search
Enter search keywords to search on Etsy. Alternative to providing search URLs in Start URLs.

### Extend output function
A JavaScript function that allows you to add custom fields to the output using Cheerio ($):

```javascript
($) => {
    const result = {};
    // Add a custom title to the output
    result.title = $('title').text().trim();
    return result;
}
```

### Custom map function
A JavaScript function that takes each result object and allows you to modify it:

```javascript
(object) => { 
    return {...object, customField: 'value'} 
}
```

### Proxy configuration
Configure proxy settings. Residential proxies are recommended for best results with Etsy.

## Output

The scraper outputs product data in the following format:

```json
{
    "url": "https://www.etsy.com/listing/...",
    "name": "Product Name",
    "price": 29.99,
    "originalPrice": 39.99,
    "currency": "USD",
    "images": ["https://..."],
    "seller": {
        "name": "Shop Name",
        "url": "https://www.etsy.com/shop/...",
        "rating": 5.0,
        "numberOfReviews": 1234
    },
    "variations": [
        {
            "label": "Size",
            "options": ["Small", "Medium", "Large"]
        }
    ],
    "variationPrices": [
        {
            "variationType": "Size",
            "variationValue": "Small",
            "priceModifier": 0
        }
    ],
    "highlights": ["Handmade", "Ships from USA"],
    "favorites": 500,
    "description": "Full product description...",
    "scrapedAt": "2024-01-01T00:00:00.000Z"
}
```

## Usage Examples

### Scrape search results
1. Add a search URL: `https://www.etsy.com/search?q=handmade+jewelry`
2. Set `Maximum number of items` to desired count
3. Set `Category end page` to number of pages to scrape

### Scrape a shop
1. Add shop URL: `https://www.etsy.com/shop/ShopName`
2. Configure pagination and item limits

### Scrape with variations
1. Enable `Include Variation Prices`
2. Add product or listing URLs
3. Note: This increases runtime significantly

## Technical Details

- **Template**: Crawlee + Playwright + Chrome (JavaScript)
- **Browser**: Chromium via Playwright
- **Anti-bot**: Session rotation, random delays, residential proxies
- **Concurrency**: Maximum 3 concurrent requests

## Cost Estimation

The actor uses residential proxies by default. Estimated costs:
- ~$0.50-1.00 per 1000 products (without variation prices)
- ~$2.00-5.00 per 1000 products (with variation prices)

## Support

For issues or feature requests, please contact the actor developer.
